# QA workflow skills

Claude Code skills for Phumeza's QA work across ClickUp, Kiwi TCMS and Akili.
Open this folder in VS Code and start Claude Code here so the skills load.

## Skills
- **clickup-kiwi-qa**: turns a failed test (a comment on a ClickUp task in Testing) into a
  Kiwi FAILED result, a failure document in Akili, and a ClickUp comment, then moves the task
  to In Progress. Example: "TID-1234 failed, check my comment". Works for Asuer and BBB tickets;
  the brand comes from the environment, using `.claude/skills/clickup-kiwi-qa/references/brands.md`.
- **clickup-kiwi-pass**: records a passed test as a Kiwi PASSED result labelled dev or
  pre-prod, writes a pass document to `tests/` and Akili › Test, and comments on the ClickUp task. Example: "TID-1234 passed on dev".
- **qa-biweekly-report**: a two-weekly test report for QA and the developers. Run manually every
  second Monday; covers the previous two full weeks (Mon–Sun).

## Setup
1. ClickUp API token (the skills use the ClickUp REST API, not MCP):
   - In ClickUp, go to Settings → Apps → API Token and generate your token (it starts with `pk_`).
   - Copy `.claude/settings.local.example.json` to `.claude/settings.local.json` and paste the
     token in. That file is in `.gitignore`, so the token is never committed.
   - Restart Claude Code, then ask: "Use clickup.mjs to show me task <ID>." If you get the
     task back, it works.
   - The token acts as you and can see everything you can. Treat it like a password, and
     regenerate it in ClickUp if it's ever exposed.
2. Kiwi API user (the skills use Kiwi's JSON-RPC API, not MCP):
   - In Kiwi, open Admin → Users and create a user called `claude-api` with a strong password.
   - Add it to the **Tester** group. That covers creating cases, adding them to plans and runs,
     setting results, and adding comments and links. Don't make it an admin.
   - Put `KIWI_URL`, `KIWI_USERNAME` and `KIWI_PASSWORD` in `.claude/settings.local.json`.
   - Restart Claude Code and ask: "Run kiwi.mjs ping." Then fill in the IDs in
     `.claude/skills/clickup-kiwi-qa/references/kiwi-defaults.md`. Claude can look them up for you.
3. Akili: every test (pass or fail) gets a document in `tests/` in this folder and under
   **Test** in Akili. Claude saves to Akili directly once the claude.ai Akili connector is
   authorised; until then, upload the files from `tests/` to Test yourself. ClickUp task IDs are custom `TID-` IDs; `CLICKUP_TEAM_ID` is set to the
   workspace ID (2637059) so the scripts can look them up.
4. Replace the placeholder in `.claude/skills/clickup-kiwi-qa/references/test-case-format.md`
   with the real Kiwi YAML format.
5. Two-weekly report (run manually):
   - Every second Monday, open this folder in VS Code and tell Claude Code:
     "Run the qa-biweekly-report for the previous two weeks."
   - Reminder: open `qa-report-reminder.ics` (in this folder) to add a repeating Monday 08:00
     event to Apple Calendar. It repeats every 2 weeks from Monday 5 October 2026.

## Still to do
- [x] ClickUp API token in settings.local.json
- [x] Report finds tickets from Kiwi + a workspace-wide in-testing search (no list IDs needed)
- [x] Akili path (tests/)
- [ ] Real Kiwi YAML format
- [x] Kiwi API user (claude-api, Tester group) + ping works
- [x] Kiwi IDs in kiwi-defaults.md (plan claude-qa, ID 3)
- [ ] Authorise the claude.ai Akili connector so documents save to Akili › Test directly
- [ ] Test on one real failed ticket
- [ ] One manual report run
