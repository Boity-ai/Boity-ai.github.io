# Test passed — [Sales Force Pay-In] A Consultant promoted after their sheet was printed can still be captured on it

| Field | Value |
|---|---|
| ClickUp task | TID-6019 — https://app.clickup.com/t/2637059/TID-6019 |
| Kiwi test case | TC-43 (plan: Sales Force (Vannessa), ID 5) |
| Kiwi run / execution | Run 24 / execution 24 |
| Dev or pre-prod | dev |
| Brand | BBB |
| Environment | brook |
| Build / PR | Brook redeploy on 2026-10-14 with the Milestone 1 changes (pay-in and promotion fixes, pay-in picker fix) |
| Tested by | Phumeza |
| Date | 2026-10-15 |
| Result | PASSED |

## Test summary
Checked that a Consultant who is promoted after their Manager's pay-in sheet was printed can still be captured on that sheet, as the person they were when it was printed. Passed on brook (dev).

## Preconditions
- A Manager's sheet that is New or Registered, with a Consultant line on it.
- The sheet, the Manager and the Consultant's SF code noted. Sheet number and SF code: Not provided.

## Steps
1. Promote the Consultant to Prospective Manager, then to Manager, with an effective date of the 1st of next month.
2. Open the Manager's sheet, receive it, and capture sales on the Consultant's line.
3. Complete the capture.

## Expected result
- The Consultant's line is still on the sheet and can be captured.
- The capture completes without an error.
- The Consultant's pay-in history for that month shows them as a Consultant in the sheet Manager's team.

## Actual result
Works as expected.

## Evidence
Attached to Phumeza's comment on TID-6019 (2026-10-15):
- Screenshot 2026-10-15 at 14.05.32.png
- Screenshot 2026-10-15 at 14.04.43.png
- Screenshot 2026-10-15 at 14.16.56.png
- Record IDs: Not provided

## History
None.
