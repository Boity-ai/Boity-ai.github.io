# Test passed — Hub: Home Team PDF invoice block do not match the online block

| Field | Value |
|---|---|
| ClickUp task | TID-4711 — https://app.clickup.com/t/2637059/TID-4711 |
| Kiwi test case | TC-39 (plan: claude-qa, ID 3) |
| Kiwi run / execution | Run 17 / execution 17 |
| Dev or pre-prod | dev |
| Brand | BBB |
| Environment | sfdev (2LA Distributors test account) |
| Build / PR | PR #1529 (invoice PDF); PR #1315 (credit notes, statements, payments) |
| Tested by | Phumeza |
| Date | 2026-10-13 |
| Result | PASSED |

## Test summary
Retest after the 2026-09-17 failure. On Home Team invoices, the PDF's fourth signature block said "MANAGER – Received by" while the online view said "CONSULTANT – Received by". The fix makes the background PDF print load the invoice's Home Team contact, so the PDF matches the online view and uses the Home Team bank account. All three tests passed.

## Preconditions
- Hub hard-refreshed (Cmd+Shift+R) on sfdev, logged in to the 2LA Distributors test account.
- A Home Team invoice that hadn't been printed before the fix (for example INV-0000703 to INV-0000709), or a newly created and confirmed one. Invoices printed earlier keep their old PDF.

## Steps
**Test 1: Home Team invoice**
1. Open a Home Team invoice, or create and confirm a new one for a Home Team consultant.
2. On the online view, check the fourth signature box reads "CONSULTANT – Received by".
3. Download or print the PDF (the first time can take about 20 seconds).
4. Check the PDF's fourth box also reads "CONSULTANT – Received by", and the Admin, Checker and Driver / Delivery boxes match the online view.

**Test 2: Manager invoice (should be unchanged)**
1. Open an invoice for a Manager.
2. Check both the online view and the PDF read "MANAGER – Received by".

**Test 3 (optional): Home Team bank account**
1. In 2LA's Hub Settings, add a second (Home Team) bank account with test details.
2. Create a new Home Team invoice and open its PDF: the banking details show the Home Team account.
3. Create a new Manager invoice and open its PDF: it still shows the main account.
4. Remove the test account from Settings.

## Expected result
- Home Team invoice: online view and PDF both read "CONSULTANT – Received by"; the other three blocks match.
- Manager invoice: online view and PDF both read "MANAGER – Received by".
- Home Team invoice PDF shows the Home Team bank account; Manager invoice PDF shows the main account.

## Actual result
- Test 1: PASSED
- Test 2: PASSED
- Test 3: PASSED

## Evidence
Attached to Phumeza's comment on TID-4711 (2026-10-13):
- Test 1: Screenshot 2026-10-13 at 10.09.40.png
- Test 2: Screenshot 2026-10-13 at 10.21.17.png
- Test 3: Screenshot 2026-10-13 at 10.45.12.png, 10.46.02.png, 10.47.32.png
- Record IDs: Not provided

## History
- 2026-09-17: FAILED on sfdev after the first fix (PR #1315). The PDF still said Manager for Home Team.
