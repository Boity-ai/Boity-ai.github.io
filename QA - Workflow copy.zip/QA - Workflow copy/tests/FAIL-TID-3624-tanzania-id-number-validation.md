# Test failure — Country List Mismatch Between Recruitment Bot and Webform

| Field | Value |
|---|---|
| ClickUp task | TID-3624 — https://app.clickup.com/t/2637059/TID-3624 |
| Kiwi test case | TC-40 (plan: claude-qa, ID 3) |
| Kiwi run / execution | Run 18 / execution 18 |
| Dev or pre-prod | dev |
| Brand | BBB |
| Environment | birch (webform-birch.dev.bbb.systems) and Dev chatbot |
| Build / PR | Not provided |
| Tested by | Phumeza |
| Date | 2026-10-13 |
| Result | FAILED |

## Test summary
Retest of the Tanzania ID number validation on the Birch recruitment webform. Tanzania was added to the webform as an option for country of birth, mobile country code and ID number (not address country). The ID number validation issue raised on 2026-08-04 has not been fixed.

## Steps to reproduce
1. Open the Birch webform (https://webform-birch.dev.bbb.systems/).
2. Select Tanzania for the ID number.
3. Enter a Tanzania ID number using different separators: hyphen (-), no separator, and slash (/).
4. Check which formats are accepted and whether a validation error is shown.

## Expected result
The Tanzania ID Number field should only accept the valid format defined by the validation rules. Invalid special characters should be rejected, and the user should see a clear validation error message.

## Actual result
This issue has not been fixed. The Tanzanian ID number accepts "-" or no spaces, and does not accept "/".

Original failure (2026-08-04): the webform accepted a backslash (\) in place of the required hyphen (-) without showing a validation error, and the application continued with an ID number in an invalid format.

## Why it failed
The Tanzania ID number validation still doesn't match the expected format.

## Evidence
Attached to Phumeza's comments on TID-3624:
- 2026-10-13 retest: Screenshot 2026-10-13 at 11.48.29.png
- 2026-08-04 original failure: Screenshot 2026-08-04 at 11.37.19.png, Screenshot 2026-08-04 at 11.37.43.png
- Record IDs: Not provided

## Retest
- 2026-10-14: PASSED on dev (birch), TC-40 run 20. See PASS-TID-3624-tanzania-id-number-validation.md.
