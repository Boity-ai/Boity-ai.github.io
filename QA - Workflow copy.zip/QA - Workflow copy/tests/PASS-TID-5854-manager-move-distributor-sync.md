# Test passed — [Sales Force Sync] Manager Move to another Distributor syncs the Manager and full team to aspen

| Field | Value |
|---|---|
| ClickUp task | TID-5854 — https://app.clickup.com/t/2637059/TID-5854 |
| Kiwi test case | TC-35 (plan: Sales Force Sync, ID 4) |
| Kiwi run / execution | Run 23 / execution 23 (re-test) |
| Dev or pre-prod | dev |
| Brand | Asuer and BBB (brook is BBB, aspen is Asuer) |
| Environment | Aspen and Brook |
| Build / PR | Not provided |
| Tested by | Phumeza |
| Date | 2026-10-14 |
| Result | PASSED |

## Test summary
Re-test after the 2026-10-12 failure, once the crons were back on. Moving a Manager to another Distributor with Manager Move on brook updates the Distributor for the Manager and their Home Team on brook, and it syncs to aspen. It works as expected.

## Preconditions
- A Manager who has a team and exists on aspen.
- The current Distributor, team size and team member IDs recorded.
- The target Distributor noted.

## Steps
1. On brook, run Manager Move to put the Manager under the target Distributor.
2. Wait 1–2 minutes.
3. On aspen, check the Manager and each team member.

## Expected result
The Manager and the Manager's Home Team should reflect the new Distributor on brook, and this should sync to aspen.

## Actual result
Works as expected.

## Evidence
Attached to Phumeza's comment on TID-5854 (2026-10-14):
- Screenshot 2026-10-14 at 12.19.04.png
- Record IDs: Not provided
- Team count on brook vs. members updated on aspen: Not provided

## Other observation (outside this test)
Aspen still shows this error. It doesn't change the result of this test; Phumeza raised it with Vanessa on TID-5854 on 2026-10-14.

```
UncaughtPromiseError
Uncaught Promise > HTTP error status: 404
Error: HTTP error status: 404
    at VoicePlayer.fetchFile (https://aspen.dev.asuer.systems/web/assets/d5fad91/web.assets_web_dark.min.js:13953:77)
```

## History
- 2026-10-09: Worked when first tested.
- 2026-10-12: FAILED (TC-35, run 13). The Manager and Home Team updated on brook but did not sync to aspen. See FAIL-TID-5854-manager-move-distributor-sync.md.
- 2026-10-14: Vanessa asked for a re-test now that the crons are back on.
- 2026-10-14: Re-test PASSED (TC-35, run 23).
