# Test passed — [Sales Force Promotions] A promotion only takes effect on the 1st of a month

| Field | Value |
|---|---|
| ClickUp task | TID-6020 — https://app.clickup.com/t/2637059/TID-6020 |
| Kiwi test case | TC-45 (plan: Sales Force (Vannessa), ID 5) |
| Kiwi run / execution | Run 26 / execution 26 |
| Dev or pre-prod | dev |
| Brand | BBB |
| Environment | brook |
| Build / PR | Brook redeploy on 2026-10-14 with the Milestone 1 changes (pay-in and promotion fixes, pay-in picker fix) |
| Tested by | Phumeza |
| Date | 2026-10-16 |
| Result | PASSED (open question; ticket moved back to In Progress) |

## Test summary
Checked that a promotion's effective date can only be the 1st of a month (the agreed rule: effective 1 November means from the selling window that starts on 8 November). Passed on brook (dev). The test passed, but Phumeza found a loophole that needs clarification, so the ticket was moved back to In Progress until Vanessa answers.

## Preconditions
- A Prospective Manager who can be promoted to Manager.

## Steps
1. Start the promotion to Manager.
2. Try an effective date on the 8th of a month.
3. Then try the 1st of next month.

## Expected result
- The 8th is not accepted (or is changed to the 1st, with a message).
- The 1st is accepted.

## Actual result
Works as expected.

What the screen does with the 8th: Not provided (see screenshots).

## Open question (for Vanessa)
Should promotions and demotions take effect on the 1st of the current month or the 1st of the following month?

Currently, a user can select the 1st of a previous month as the effective date, and the promotion takes effect immediately. Should the system prevent users from selecting past dates?

## Evidence
Attached to Phumeza's comment on TID-6020 (2026-10-16):
- Screenshot 2026-10-16 at 10.19.54.png
- Screenshot 2026-10-15 at 14.54.54.png
- Record IDs: Not provided

## History
- 2026-10-16: PASSED on brook (dev); moved back to In Progress pending the open question above.
