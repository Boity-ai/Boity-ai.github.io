# Test passed — [Sales Force Demotions] A demotion moves the team to the suggested place, and a target being demoted is refused

| Field | Value |
|---|---|
| ClickUp task | TID-6026 — https://app.clickup.com/t/2637059/TID-6026 |
| Kiwi test case | TC-44 (plan: Sales Force (Vannessa), ID 5) |
| Kiwi run / execution | Run 25 / execution 25 |
| Dev or pre-prod | dev |
| Brand | BBB |
| Environment | brook |
| Build / PR | Brook redeploy on 2026-10-14 with the Milestone 1 changes (pay-in and promotion fixes, pay-in picker fix) |
| Tested by | Phumeza |
| Date | 2026-10-16 |
| Result | PASSED |

## Test summary
Checked that demoting a Manager moves their whole team to the suggested place, and that the screen refuses to move a team to someone who is being demoted themselves. Passed on brook (dev).

## Preconditions
- A Manager with a team, and a second Manager.
- SF codes before and after: Not provided.

## Steps
1. Start a demotion of the first Manager, effective the 1st of next month. Leave the suggested target for the team. Check Who Moves, Confirm, then apply.
2. Check the team members' Manager and the demoted person's new place.
3. Start a demotion of the second Manager, then try to demote another Manager with their team moving to the second Manager.

## Expected result
- The whole team moved to the suggested target; the demoted person sits where the screen said.
- Step 3 is refused with a message.

## Actual result
Works as expected.

Refusal message from step 3: Not provided (see screenshots).

## Evidence
Attached to Phumeza's comment on TID-6026 (2026-10-16):
- Screenshot 2026-10-15 at 14.54.54.png
- Screenshot 2026-10-15 at 14.54.41.png
- When a user tries to promote a Prospective Manager before the 1st of the month: Screenshot 2026-10-16 at 08.32.26.png
- Record IDs: Not provided

## History
None.
