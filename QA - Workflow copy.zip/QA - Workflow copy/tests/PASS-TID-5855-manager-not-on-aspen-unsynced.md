# Test passed — [Sales Force Sync] Consultant assigned a Manager that doesn't exist on aspen stays unsynced

| Field | Value |
|---|---|
| ClickUp task | TID-5855 — https://app.clickup.com/t/2637059/TID-5855 |
| Kiwi test case | TC-36 (plan: Sales Force Sync, ID 4) |
| Kiwi run / execution | Run 14 / execution 14 |
| Dev or pre-prod | dev |
| Brand | Asuer and BBB (brook is BBB, aspen is Asuer) |
| Environment | Aspen and Brook |
| Build / PR | Not provided |
| Tested by | Phumeza |
| Date | 2026-10-12 |
| Result | PASSED |

## Test summary
Checked how the sync handles a Consultant whose Manager doesn't exist on aspen. The Manager change was saved on brook and, as expected, was not synced to aspen.

## Preconditions
- A Consultant who exists on aspen, with their current Manager recorded on both environments.
- Test Manager: 1133348 (Getrud Iiyambo), who does not exist on aspen.

## Steps
1. On brook, open the Consultant.
2. Set Manager to 1133348 (Getrud Iiyambo) and save.
3. Wait 1–2 minutes, then check the member on aspen.
4. On brook, open the list view and go to Filters → custom filter → Last Outbound Sync Date is not set.

## Expected result
- On aspen, nothing changes for this member.
- On brook, the filter still returns this Consultant.

## Actual result
The Manager updated on brook but not on aspen, because the Manager does not exist on aspen.

## Evidence
- Screenshot 2026-10-12 at 14.08.26.png (attached to the ClickUp comment on TID-5855)
- Screenshot 2026-10-12 at 14.09.32.png (attached to the ClickUp comment on TID-5855)
- Record IDs: Not provided
