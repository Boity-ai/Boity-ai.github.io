# Test passed — [Sales Force Sync] Bulk Active Status change (20–50 Consultants) syncs completely to aspen

| Field | Value |
|---|---|
| ClickUp task | TID-5853 — https://app.clickup.com/t/2637059/TID-5853 |
| Kiwi test case | TC-41 (plan: Sales Force Sync, ID 4) |
| Kiwi run / execution | Run 22 / execution 22 (re-test) |
| Dev or pre-prod | dev |
| Brand | Asuer and BBB (brook is BBB, aspen is Asuer) |
| Environment | Aspen and Brook |
| Build / PR | Not provided |
| Tested by | Phumeza |
| Date | 2026-10-14 |
| Result | PASSED |

## Test summary
Re-test after the 2026-10-13 failure. A bulk Active Status change on brook, done by export and re-import, reaches aspen for every member in it. It works as expected.

The 2026-10-13 failure was that the change was recorded in aspen's chatter but not brook's. Vanessa confirmed this isn't a bug: Odoo's import screen switches history tracking off by default to make big imports faster. A normal save does record it (as in TID-5851). To record it during an import, open the import screen in debug mode (https://brook.dev.bbb.systems/web?debug=1#action=import&model=sf.member) and tick "Track history during import" under Advanced.

## Preconditions
- 20–50 Consultants who all exist on aspen.
- Export is visible on the Consultants list.

## Steps
1. On brook, in the Consultants list, select 20–50 Consultants.
2. Export them: tick **I want to update data (import-compatible export)**, then add the **Active Status** field. Odoo adds an ID column by itself: that's Odoo's own record ID (it looks like `__export__.sf_member_12345_…`), not the SA ID number or the SF code. Leave it as it is. Keep a copy of the original file.
3. In the file, change Active Status for every row to a different valid value, spelled exactly as it appears in the export (e.g. another row's value).
4. Import the file back on the import screen, which the members lists don't offer, so open it with this link: brook.dev.bbb.systems/web#action=import&model=sf.member. Load the file; Odoo matches the rows on the ID column.
   For this re-test, "Track history during import" was ticked (under Advanced, with the import screen in debug mode).
5. Wait 1–2 minutes, then check every member on aspen.

## Expected result
- The import saves every row.
- Every member on aspen shows the new BBB Active Status.
- None are missing or still on the old status.

## Actual result
Works as expected.

"Track history during import" was ticked for this re-test, as Vanessa asked.

## Evidence
Attached to Phumeza's comment on TID-5853 (2026-10-14):
- Screenshot 2026-10-14 at 11.51.22.png
- Rows imported / synced: Not provided
- Record IDs: Not provided

## History
- 2026-10-13: FAILED (TC-41, run 19). The Active Status change synced, but it was recorded in the chatter on aspen and not on brook. See FAIL-TID-5853-bulk-active-status-chatter-missing-on-brook.md.
- 2026-10-14: Vanessa confirmed the sync part passed and the missing brook chatter is Odoo's import default, not a bug.
- 2026-10-14: Re-test PASSED (TC-41, run 22), with "Track history during import" ticked.
