# Test result — BBB Recruiter Assignment Rules Update (SF)

| Field | Value |
|---|---|
| ClickUp task | TID-144 — https://app.clickup.com/t/2637059/TID-144 |
| Kiwi test cases | TC-32 (Mobile 2 duplicate check) — PASSED on retest, run 9; TC-33 (Date of Birth update) — PASSED on retest, run 12; TC-42 (existing recruiter not overwritten) — PASSED, run 21 |
| Dev or pre-prod | dev |
| Brand | BBB |
| Environment | birch |
| Build / PR | Not provided |
| Tested by | Phumeza |
| Date | 2026-10-08 (first test); 2026-10-12 (TC-33 retest); 2026-10-14 (TC-42) |
| Result | PASSED |

## Test summary
The manual capture case was tested with the Create a Consultant wizard in Odoo. The main scenario passed. The Mobile 2 duplicate check first failed (run 8) and passed on retest (run 9). A different issue was then found: when a new lead is created with the same mobile number but a different ID number, the existing Date of Birth is not updated (run 10). It passed on retest on 2026-10-12 (run 12). On 2026-10-13 Zack added one more rule: when there is an existing recruit, the recruiter information should not be overwritten, even if different recruiter details are supplied in the Create Consultant wizard. It passed on 2026-10-14 (run 21). All cases on this ticket have now passed.

## Passed — Existing recruiter not overwritten (TC-42)

### Rule (added by Zack, 2026-10-13)
When there is an existing recruit, the recruiter information should not be overwritten, even if different recruiter details are supplied in the Create Consultant wizard.

### Steps (2026-10-14)
1. Pick (or create) an existing recruit with a known recruiter. Note the recruiter name and code, plus the recruit's ID number or phone, whichever the system uses to match people.
2. Open the Create Consultant wizard for that same person, using the same identifying details so the system matches the existing recruit.
3. In the wizard, choose a different recruiter, then complete the wizard.
4. Open the resulting consultant/recruit record. The recruiter should still be the original one. Check the chatter/history too: there should be no "Recruiter: A → B" change logged.
5. Check that no duplicate person record was created.

### Expected result
When the Create Consultant wizard is completed for an existing recruit with different recruiter details, the wizard reuses the existing record without creating a duplicate, keeps the original recruiter unchanged, and logs no recruiter change in the chatter.

### Result (run 21) — PASSED
Works as expected.

### Evidence
- Screenshot 2026-10-14 at 10.34.48.png
- Screenshot 2026-10-14 at 10.36.20.png
- Screenshot 2026-10-14 at 10.37.25.png
- Record IDs: Not provided

## Resolved on retest — Date of Birth update (TC-33)

### Original failure (run 10)
Some leads in the Lead stage that have not yet become Sales Force Members already have an ID number and Date of Birth populated. When a new lead was created using the same mobile number but with a different ID number, the existing Date of Birth was not updated.

### Retest steps (2026-10-12)
1. Look for a lead with a DoB/ID number that has not been created as a Sales Force Member.
2. Create a consultant with a different ID number.

### Expected result
After successfully creating a consultant, the DoB should update to reflect the updated ID number.

### Retest result (run 12) — PASSED
The DoB updated to reflect the updated ID number.

### Evidence
- Original failure: Screenshot 2026-10-08 at 13.39.18.png
- Retest: Screenshot 2026-10-12 at 08.02.36.png
- Record IDs: Not provided

## Resolved on retest — Mobile 2 duplicate check (TC-32)

### Original failure (run 8)
A Potential Consultant (PC) had two different mobile numbers. A second PC joined through Pay-in Sheets using the existing mobile 2 number in Odoo, but with a different ID number. Now there are same numbers with 2 different people.

### Expected result
The system should check both Mobile and Mobile 2 when validating for duplicate records and prevent a duplicate record from being created when either number already exists.

### Retest result (run 9) — PASSED
The issue has been resolved. The system now checks Mobile 2 as part of the duplicate validation logic and correctly identifies the number as a duplicate.

### Evidence
- Original failure: Screenshot 2026-10-08 at 10.35.00.png, Screenshot 2026-10-08 at 10.40.13.png
- Retest: Screenshot 2026-10-08 at 12.49.10.png
- Record IDs: Not provided

## Passed in this test
- Main scenario: a lead that had not yet become a Sales Force Member was created as a Consultant through the "Create a Consultant" wizard with no errors (Screenshot 2026-10-08 at 10.15.02.png, Screenshot 2026-10-08 at 10.22.15.png).
