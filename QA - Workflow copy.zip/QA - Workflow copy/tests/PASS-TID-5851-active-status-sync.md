# Test passed — [Sales Force Sync] Active Status change on a single Consultant syncs from brook to aspen

| Field | Value |
|---|---|
| ClickUp task | TID-5851 — https://app.clickup.com/t/2637059/TID-5851 |
| Kiwi test case | TC-37 (plan: Sales Force Sync, ID 4) |
| Kiwi run / execution | Run 15 / execution 15 |
| Dev or pre-prod | dev |
| Brand | Asuer and BBB (brook is BBB, aspen is Asuer) |
| Environment | Aspen and Brook |
| Build / PR | Not provided |
| Tested by | Phumeza |
| Date | 2026-10-12 |
| Result | PASSED |

## Test summary
Checked that changing a Consultant's Active Status on brook reaches aspen within a minute or two, without the save on brook waiting for the sync. It worked as expected.

## Preconditions
- One Consultant who exists on both brook and aspen.
- Their current Active Status noted on both environments.

## Steps
1. On brook, open the Consultant.
2. Change Active Status and save.
3. Note whether the save finishes immediately or hangs.
4. Within 1–2 minutes, open the same member on aspen.

## Expected result
- On brook, the save finishes straight away and doesn't wait on aspen.
- On aspen, the BBB Active Status matches the new value.
- On aspen, the chatter logs the status change.

## Actual result
Works as expected.

## Evidence
- Screenshot 2026-10-12 at 14.27.42.png (attached to the ClickUp comment on TID-5851)
- Consultant ID, old and new status, save and sync times: Not provided

## Other observation (outside this test)
BBB Join Date and Last BBB Sale Date do not match between brook and aspen for the same member. This is outside the scope of this test and doesn't change its result; it was raised with Vanessa in a separate comment.

| Field | Brook | Aspen |
|---|---|---|
| BBB Join Date | 05/23/2022 | 06/06/2022 |
| Last BBB Sale Date | 04/01/2026 | 01/09/2024 |
