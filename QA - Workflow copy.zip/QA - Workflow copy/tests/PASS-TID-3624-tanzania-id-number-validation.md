# Test passed — Country List Mismatch Between Recruitment Bot and Webform

| Field | Value |
|---|---|
| ClickUp task | TID-3624 — https://app.clickup.com/t/2637059/TID-3624 |
| Kiwi test case | TC-40 (plan: claude-qa, ID 3) |
| Kiwi run / execution | Run 20 / execution 20 |
| Dev or pre-prod | dev |
| Brand | BBB |
| Environment | birch (webform-birch.dev.bbb.systems) |
| Build / PR | Not provided |
| Tested by | Phumeza |
| Date | 2026-10-14 |
| Result | PASSED |

## Test summary
Retest of the Tanzania ID number validation on the Birch recruitment webform after the 2026-10-13 failure. The fix stores Tanzanian ID numbers without the optional separators: if "/" or "\" is entered in the correct places, the ID number is accepted and the separator is stripped, so a valid value is stored. This matches the existing validation on Zimbabwe ID numbers. It works as expected.

## Steps
1. Open the BBB Birch webform (https://webform-birch.dev.bbb.systems/).
2. Complete the webform using a Tanzanian ID number with the "/" character instead of the required hyphen "-".
3. Submit the webform.
4. Check the ID number on the record in Odoo.

## Expected result
The Tanzania ID Number field should only accept the valid separator format (hyphen -) as defined by the validation rules. Invalid special characters, including the backslash (\), should be rejected, and the user should be presented with an appropriate validation error message.

## Actual result
The webform accepts the "/" character and submits successfully. However, in Odoo, the value is displayed in the correct continuous format without the "/". This is acceptable and works as expected.

## Evidence
Attached to Phumeza's comment on TID-3624 (2026-10-14):
- Screenshot 2026-10-14 at 08.18.54.png
- Screenshot 2026-10-14 at 09.49.14.png
- Record IDs: Not provided

## History
- 2026-08-04: FAILED. The webform accepted a backslash (\) in place of the hyphen (-) without a validation error.
- 2026-10-13: FAILED on birch (TC-40, run 18). The field accepted "-" or no separator but not "/". See FAIL-TID-3624-tanzania-id-number-validation.md.
- 2026-10-13: Zack changed the fix so "/" and "\" separators are accepted and stripped before the value is stored.
