# Test passed — [Sales Force Sync] Archiving a Consultant on brook archives the member on aspen

| Field | Value |
|---|---|
| ClickUp task | TID-5856 — https://app.clickup.com/t/2637059/TID-5856 |
| Kiwi test case | TC-34 (plan: Sales Force Sync, ID 4) |
| Kiwi run / execution | Run 11 / execution 11 |
| Dev or pre-prod | dev |
| Brand | Asuer and BBB (brook is BBB, aspen is Asuer) |
| Environment | Aspen and Brook |
| Build / PR | Not provided |
| Tested by | Phumeza |
| Date | 2026-10-09 |
| Result | PASSED |

## Test summary
Checked that archiving a Consultant on brook archives the matching member on aspen. Archiving did not sync before, so this verifies the fix. It passed and is kept as a regression case.

## Preconditions
- A Consultant who exists and is active on both environments.
- A test record, or one confirmed safe to archive.

## Steps
1. On brook, archive the Consultant.
2. Wait 1–2 minutes.
3. On aspen, search for the member, including archived records.

## Expected result
The consultant archived on brook shows as archived on aspen.

## Actual result
The consultant archived on brook shows as archived on aspen.

## Evidence
- Screenshot 2026-10-09 at 08.36.15.png (attached to the ClickUp comment on TID-5856)
- Record IDs: Not provided
