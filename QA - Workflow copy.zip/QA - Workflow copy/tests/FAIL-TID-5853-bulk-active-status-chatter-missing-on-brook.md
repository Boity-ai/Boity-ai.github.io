# Test failure — [Sales Force Sync] Bulk Active Status change (20–50 Consultants) syncs completely to aspen

| Field | Value |
|---|---|
| ClickUp task | TID-5853 — https://app.clickup.com/t/2637059/TID-5853 |
| Kiwi test case | TC-41 (plan: Sales Force Sync, ID 4) |
| Kiwi run / execution | Run 19 / execution 19 |
| Dev or pre-prod | dev |
| Brand | Asuer and BBB (brook is BBB, aspen is Asuer) |
| Environment | Aspen and Brook |
| Build / PR | Not provided |
| Tested by | Phumeza |
| Date | 2026-10-13 |
| Result | FAILED |

## Test summary
Checked that a bulk Active Status change on brook, done by export and re-import, reaches aspen for every member in it. The status change itself works, but the change is recorded in the chatter on aspen and not on brook.

## Preconditions
- 20–50 Consultants who all exist on aspen.
- Export is visible on the Consultants list.

## Steps to reproduce
1. On brook, in the Consultants list, select 20–50 Consultants.
2. Export them: tick **I want to update data (import-compatible export)**, then add the **Active Status** field. Leave the **ID** column Odoo adds as it is. Keep a copy of the original file.
3. In the file, change Active Status for every row to a different valid value, spelled exactly as it appears in the export.
4. Import the file on brook's import screen (https://brook.dev.bbb.systems/web#action=import&model=sf.member). Odoo matches the rows on the ID column.
5. Wait 1–2 minutes, then check every member on aspen, and the chatter on brook and aspen.

## Expected result
- The import saves every row.
- Every member on aspen shows the new BBB Active Status.
- None are missing or still on the old status.

## Actual result
The Active Status change works as expected. However, the change is recorded in the chatter on Aspen but not on Brook.

For example, Aspen records the Active Status change from Active 6 to Active 1 in the chatter, while Brook does not record the change.

## Why it failed
The bulk Active Status change made through import is not recorded in brook's chatter, although aspen's chatter records it.

## Evidence
Attached to Phumeza's comment on TID-5853 (2026-10-13):
- Screenshot 2026-10-13 at 15.42.46.png
- Screenshot 2026-10-13 at 15.42.38.png
- Rows imported / synced: Not provided
- Record IDs: Not provided

## Retest
- 2026-10-14: PASSED on dev (Aspen and Brook), TC-41 run 22. The missing chatter on brook is not a bug: Odoo's import screen switches history tracking off by default (per Vanessa). "Track history during import" was ticked for the re-test. See PASS-TID-5853-bulk-active-status-sync.md.
