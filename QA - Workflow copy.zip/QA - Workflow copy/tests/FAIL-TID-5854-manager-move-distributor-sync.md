# Test failure — [Sales Force Sync] Manager Move to another Distributor syncs the Manager and full team to aspen

| Field | Value |
|---|---|
| ClickUp task | TID-5854 — https://app.clickup.com/t/2637059/TID-5854 |
| Kiwi test case | TC-35 (plan: Sales Force Sync, ID 4) |
| Kiwi run / execution | Run 13 / execution 13 |
| Dev or pre-prod | dev |
| Brand | Asuer and BBB (brook is BBB, aspen is Asuer) |
| Environment | Aspen and Brook |
| Build / PR | Not provided |
| Tested by | Phumeza |
| Date | 2026-10-12 |
| Result | FAILED |

## Test summary
Checked that moving a Manager to another Distributor with Manager Move on brook updates the Distributor on aspen for the Manager and their whole team. The move updates on brook but does not sync to aspen. This worked when tested on Friday (2026-10-09) but failed on retest today.

## Preconditions
- A Manager who has a team and exists on aspen.
- The current Distributor, team size and team member IDs recorded.
- The target Distributor noted.

## Steps to reproduce
1. On brook, run Manager Move to put the Manager under the target Distributor.
2. Wait 1–2 minutes.
3. On aspen, check the Manager and each team member.

## Expected result
The Manager and the Manager's Home Team should reflect the new Distributor on brook, and this should sync to aspen.

## Actual result
The Manager and the Manager's Home Team update on brook but do not sync to aspen. Aspen still shows the previous Distributor.

## Why it failed
The Manager Move change is not synced from brook to aspen. It worked on 2026-10-09, so something has changed since then.

Aspen repeatedly shows this error:

```
UncaughtPromiseError
Uncaught Promise > HTTP error status: 404
Error: HTTP error status: 404
    at VoicePlayer.fetchFile (https://aspen.dev.asuer.systems/web/assets/d5fad91/web.assets_web_dark.min.js:13953:77)
```

## Evidence
- Screenshot 2026-10-12 at 08.48.26.png (attached to the ClickUp comment on TID-5854)
- Screenshot 2026-10-12 at 08.47.36.png (attached to the ClickUp comment on TID-5854)
- Record IDs: Not provided
- Team count on brook vs. members updated on aspen: Not provided

## Retest
- 2026-10-14: PASSED on dev (Aspen and Brook), TC-35 run 23, after the crons were turned back on. See PASS-TID-5854-manager-move-distributor-sync.md.
