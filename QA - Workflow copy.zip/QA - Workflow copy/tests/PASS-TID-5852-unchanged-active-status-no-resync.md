# Test passed — [Sales Force Sync] Re-saving an unchanged Active Status does not rewrite the record on aspen

| Field | Value |
|---|---|
| ClickUp task | TID-5852 — https://app.clickup.com/t/2637059/TID-5852 |
| Kiwi test case | TC-38 (plan: Sales Force Sync, ID 4) |
| Kiwi run / execution | Run 16 / execution 16 |
| Dev or pre-prod | dev |
| Brand | Asuer and BBB (brook is BBB, aspen is Asuer) |
| Environment | Aspen and Brook |
| Build / PR | Not provided |
| Tested by | Phumeza |
| Date | 2026-10-12 |
| Result | PASSED |

## Test summary
Checked that the sync only sends real changes: saving a Consultant on brook without changing Active Status does not update aspen again or add a chatter entry. It worked as expected.

## Preconditions
- TID-5851 has passed, and the same Consultant is used.
- The latest chatter entry on aspen for this member noted.

## Steps
1. On brook, re-open the same Consultant.
2. Save without changing Active Status.
3. Wait 1–2 minutes, then open the member on aspen.

## Expected result
- No new chatter entry on aspen.
- BBB Active Status on aspen is unchanged.

## Actual result
Works as expected.

## Evidence
- Screenshot 2026-10-12 at 15.20.18.png (attached to the ClickUp comment on TID-5852)
- Record IDs: Not provided

## Other observation (outside this test)
When a user clears the Active Status field on brook (leaves it empty), the change is only reflected on brook (BBB); the status on aspen (Asuer) stays unchanged. When the Active Status is changed to a different value instead, the update is reflected on both brook and aspen.

This doesn't change the result of this test. Whether clearing the field should sync is for Vanessa to confirm.
