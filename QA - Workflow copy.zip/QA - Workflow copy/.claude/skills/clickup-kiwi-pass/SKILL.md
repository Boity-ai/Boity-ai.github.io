---
name: clickup-kiwi-pass
description: Record a passed test on a ClickUp task (in the Testing status) as a Kiwi TCMS PASSED result, with Phumeza's dev or pre-prod label, write a pass document to tests/ and Akili › Test, and post a ClickUp comment. Use this whenever Phumeza says a ClickUp task or ticket passed testing ("TID-1234 passed on dev", "TID-5661 passed pre-prod"), asks to log a pass in Kiwi, or pastes a ClickUp task ID or link alongside words like passed, works, good to go, or signed off, even if she doesn't name Kiwi.
---

# ClickUp → Kiwi passed-test workflow

Phumeza is the sole QA tester across Asuer and BBB environments. When a test passes, this
skill records it:

1. A Kiwi TCMS execution set to **PASSED**, labelled dev or pre-prod
2. A pass document, saved in `tests/` and under **Test** in Akili
3. A ClickUp comment saying where it passed
4. A ClickUp status change, only if she names one

This is the passing counterpart to the **clickup-kiwi-qa** skill (failures). It uses the same
scripts and the same token and password rules. Read that skill's "Current connection level"
section for the command list. Never print the ClickUp token or the Kiwi password.

Run the scripts from the project root so the permission rules match:
- `node .claude/skills/clickup-kiwi-qa/scripts/clickup.mjs ...`
- `node .claude/skills/clickup-kiwi-qa/scripts/kiwi.mjs ...`

Every test is documented, passes as well as failures. Follow the "Akili (every test, pass or
fail)" section of the clickup-kiwi-qa skill for where the document goes.

## Dev or pre-prod
Phumeza says which one it passed on. Use her label exactly as given. If she doesn't say,
ask. Never work it out from an environment name. The two-weekly report counts passes and
failures from this label, so it must be in both the Kiwi comment and the ClickUp comment.

## ClickUp status
- The task should be in **in testing**. If it isn't, say what status it's in and ask before
  going on.
- Only change the status if she names the new one (for example "ready to deploy"). If she
  doesn't, leave it as it is: a dev pass usually still needs pre-prod testing. Check the name
  against `statuses <listId>` for the task's list before using it.

## Workflow

### 1. Gather
- Get the task (`task`, then `comments`): title, status, list, and any comment she left about
  the test.
- Confirm the dev or pre-prod label, and the environment (it becomes the Kiwi build).
- Work out the **brand**, Asuer or BBB, using `../clickup-kiwi-qa/references/brands.md`. If the
  environment isn't listed there, or the ClickUp space or list says a different brand, ask.
- Note what the pass document needs: preconditions, steps, expected result, evidence
  (screenshots, record IDs), build or PR. Take them from the task and her comments; ask once,
  together, for anything missing. If she doesn't have it, mark it "Not provided".
- Check `tests/` for earlier documents on the same task ID (e.g. a FAIL doc) for the History
  section.
- Kiwi **Test Plan**: use the `claude-qa` plan (ID 3) from
  `../clickup-kiwi-qa/references/kiwi-defaults.md` for every ticket, Asuer or BBB. Use a
  different plan only if she names one for that ticket.

### 2. Show the plan and wait
Show a short numbered plan:
1. The brand, the Kiwi case (new or existing), the build, and the new run, marked PASSED
2. The pass document you'll write, saved to `tests/` and to Test in Akili
3. The ClickUp comment you'll post
4. The status change, or "status unchanged"

Then ask her to reply "go". **Do not write to Kiwi, post to ClickUp or change a status before
she says go.**

### 3. Kiwi (after "go")
1. `find-case` using the ClickUp task title. If a matching case exists, use it. Otherwise
   `create-case` (IDs from `../clickup-kiwi-qa/references/kiwi-defaults.md`), then
   `add-to-plan` to the `claude-qa` plan, or to the plan she named.
2. `build 8 "<environment>"` to get the build for the environment on the ClickUp ticket.
   Then create a **new run for this result** (she never reuses runs):
   `new-run 3 <buildId> <caseId> "TID-<number>: <task title> — <environment> — <YYYY-MM-DD>"`.
   It returns the execution ID. Use a different plan ID only if she named one.
3. `pass <executionId> "QA passed on <dev|pre-prod>. Brand: <Asuer|BBB>. <her note, if any>"`.
4. `link <executionId> <ClickUp task URL> "ClickUp <task ID>"`. After the pass document is
   written, `link` it too.
5. Report the case ID, execution ID and run back to her.

If Kiwi can't be reached, say so plainly and give her the click-through steps from
`../clickup-kiwi-qa/references/kiwi-manual-steps.md`, with **PASSED** in place of FAILED.

### 4. Pass document (after "go")
Write it using `../clickup-kiwi-qa/references/pass-doc-template.md`. Save it as
`PASS-<ClickUp task ID>-<short-slug>.md` (e.g. `PASS-TID-4711-home-team-invoice-pdf-signature-block.md`)
in the `tests/` folder at the project root, then save it under **Test** in Akili. If a ticket
passes on both dev and pre-prod, write one document per result; add `-preprod` to the slug of
the pre-prod one so it doesn't overwrite the dev one.

### 5. ClickUp (after "go")
- Post a comment (`comment`):
  `QA passed on <dev|pre-prod> (<Asuer|BBB> <environment>). Kiwi case: TC-<ID> (run <run name>).
  Pass document: <file name> (Akili › Test).`
- Change the status only if she named one, and confirm the returned status matches.
- Confirm what was done. Clearly mark any step she still needs to do herself.

## Rules
- Never invent IDs, results, environments or brands. Ask, or mark them "Not provided".
- Kiwi is the source of truth for test results, and ClickUp for task status.
- If the status change fails, report it plainly and leave the status as it is.
