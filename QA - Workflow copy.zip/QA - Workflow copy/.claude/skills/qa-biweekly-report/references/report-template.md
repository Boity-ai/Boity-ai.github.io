# QA Test Report — <DD Mon> to <DD Mon YYYY>

Prepared by Phumeza (QA) · Brands: <Asuer, BBB> · Environments: <list>

## At a glance
| Tested | Passed | Failed | Still in Testing | Repeat failures |
|---|---|---|---|---|
| n | n | n | n | n |

## By brand
| Brand | Tested | Passed | Failed | Still in Testing | Repeat failures |
|---|---|---|---|---|---|
| Asuer | n | n | n | n | n |
| BBB | n | n | n | n | n |

## Dev vs pre-prod
| Passed dev | Failed dev | Passed pre-prod | Passed dev, failed pre-prod |
|---|---|---|---|
| n | n | n | n |

## Failed dev
Failed on dev, so not yet ready for pre-prod.
| Task | Brand | Developer | Date failed | What failed (one line) | Reason it went back to In Progress | Failure doc |
|---|---|---|---|---|---|---|

## Passed dev, failed pre-prod
Worked on dev, then failed on pre-prod.
| Task | Brand | Developer | Dev pass date | Pre-prod fail date | What failed (one line) | Failure doc |
|---|---|---|---|---|---|---|

## Needs developer attention
Failed tasks, now back in In Progress.
| Task | Brand | Developer | Environment | What failed (one line) | Reason it went back to In Progress | Failure doc | Kiwi case |
|---|---|---|---|---|---|---|---|

## Common issues
Failures on different tickets that share the same cause, module, feature or error.
| Issue | Tickets affected | What they have in common | Brand(s) | Environment(s) |
|---|---|---|---|---|

## Repeat failures
Tasks that failed more than once, or also failed last period.
| Task | Brand | Times failed | Developer | Notes |
|---|---|---|---|---|

## Ready for retest
Tasks back in Testing after a fix.
| Task | Brand | Developer | Previously failed on |
|---|---|---|---|

## Passed this period
| Task | Brand | Developer | Environment |
|---|---|---|---|

## Still in Testing
| Task | Brand | In Testing since | Blocker (if any) |
|---|---|---|---|

## Kiwi results by environment
Totals from the claude-qa plan, one row per environment (Kiwi build), grouped by brand.
| Brand | Environment | Dev or pre-prod | Passed | Failed | Blocked | Not run | Total |
|---|---|---|---|---|---|---|---|

## Gaps in this report
Anything that couldn't be collected (e.g. Kiwi not connected, missing failure doc, unknown brand).
