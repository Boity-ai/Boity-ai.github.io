---
name: qa-biweekly-report
description: Build Phumeza's two-weekly QA test report for herself and the developers, from ClickUp tasks that went through Testing, Kiwi TCMS run results, and the failure documents saved in Akili. Use this every second Monday when she asks for the two-weekly report, or whenever she asks for a test report, QA report, sprint or fortnight summary, "what failed this period", or a retest list — even if she doesn't say "biweekly".
---

# Two-weekly QA test report

Readers: Phumeza and the developers. It's a working document: what to fix, what to
retest, and what's still open. Keep it factual, link everything, and never pad it out.

## Period
The report runs on the Monday after each two-week period. Default period: the two full
weeks before the run day, Monday to Sunday (Africa/Johannesburg time). For example, a run on
Monday 19 Oct covers Mon 5 Oct to Sun 18 Oct. The run day itself is not included.
If she names a different range, use that. State the exact dates at the top of the report.

## Gather (in this order)
1. **Tested tickets, from Kiwi** (via `../clickup-kiwi-qa/scripts/kiwi.mjs tested-tickets
   <period start> <run day> 3`): every ticket with a result in the `claude-qa` plan in the
   period, found by the TID- number in the case title. For each ticket you get every result in
   date order: environment (the Kiwi build), PASSED or FAILED, and the comments. The comment
   holds her dev or pre-prod label ("QA passed on dev", "QA failed on pre-prod"). This is the
   source for passed and failed. Previous periods work the same way, with earlier dates.
2. **ClickUp** (REST API, via `../clickup-kiwi-qa/scripts/clickup.mjs`; see that skill for the
   commands and the token rules):
   - For each tested ticket: `task <TID>` for the title, link, list, assignee (developer)
     and current status, and `comments <TID>` for her failure reasons.
   - `in-testing`: every task in the whole workspace that is in "in testing" now. Those with
     no result in Kiwi in the period go under "Still in Testing". Use `time-in-status <id>`
     for when they entered testing. If the Time in Status ClickApp isn't enabled, use the
     date last updated, and say so under "Gaps in this report".
3. **Kiwi totals** (API, via `../clickup-kiwi-qa/scripts/kiwi.mjs by-environment <period start>
   <run day> 3`): every result gets its own test run, so don't report run by run. Total the
   results in the `claude-qa` plan (ID 3) per environment (the Kiwi build): PASSED, FAILED,
   BLOCKED and IDLE counts, and the failed case IDs. The run day is excluded.
   If the script can't reach Kiwi, write "Kiwi data not available — counts from ClickUp only"
   in the report. Don't estimate the numbers.
4. **Test documents** (`tests/` at the project root, the same files saved under Test in
   Akili): failure documents (`FAIL-TID-<number>-*.md`) and pass documents
   (`PASS-TID-<number>-*.md`) dated in the period. Link each one from its task.

## Brand
Every ticket is for Asuer or BBB. For each tested ticket, take the brand from the
"Brand: Asuer" or "Brand: BBB" in its Kiwi comment. Results logged before brands were added
won't have it, so look up the environment (the Kiwi build) in
`../clickup-kiwi-qa/references/brands.md` instead. For tickets still in Testing, which have no
Kiwi result yet, use the ClickUp space, folder or list name only if it says Asuer or BBB.
If none of these gives the brand, write "Unknown" in the Brand column and list the ticket
under "Gaps in this report". Don't guess.

Show the brand in every ticket table, and fill the "By brand" table with the same counts as
"At a glance", split by brand. A ticket counts under one brand only.

## Dev vs pre-prod
Phumeza writes down herself which environment each test was run on: dev or pre-prod. Use
her label exactly as written. Read it from her ClickUp comment on the task or from the Kiwi
run's build, whichever has it. Never work out the environment from an environment name
(sfdev, dev7, ...) yourself. If a tested task has no environment label, leave it
out of these counts and list it under "Gaps in this report".

For each task tested in the period, take its latest dev result and its latest pre-prod
result. A dev result from before the period still counts if the pre-prod test was in the
period. Then count:
- **Passed dev:** the latest dev result is a pass.
- **Failed dev:** the latest dev result is a fail. List each of these tasks in the
  "Failed dev" section with the date it failed, taken from her ClickUp failure comment or the
  Kiwi result.
- **Passed pre-prod:** the latest pre-prod result is a pass.
- **Passed dev, failed pre-prod:** passed on dev, but the latest pre-prod result is a fail.
  List each of these tasks individually, because they show something that worked on dev but
  broke on the way to production.

A task counts once in each figure, however many times it was retested.

## Why it went back to In Progress
For each failed task, fill "Reason it went back to In Progress" from Phumeza's failure
comment on ClickUp, or from the "Why it failed" section of its failure document. Use her
wording, shortened if needed but not reinterpreted. If neither gives a reason, write
"Not provided".

## Repeat failures
Flag any task that failed more than once in the period, or that also failed in the
previous report. These matter most to developers.

## Common issues
Look across all the failures in the period, on different tickets, for ones that share the
same cause, Odoo module or feature, error message, or step that breaks. Group them in the
"Common issues" section, listing each ticket and what they have in common. Only group
failures when her comments or failure documents clearly describe the same issue. Don't group
by guesswork or suggest hidden causes. A group needs at least two tickets. If nothing
matches, write "None this period".

## Output
Write the report using `references/report-template.md`. Save it as
`QA-Report-<YYYY-MM-DD>.md` in the `tests/` folder and
summarise it in one short message.

## Rules
- Report only what the data shows. Leave out "likely causes" unless a failure document states one.
- A section with nothing in it shows "None this period". Don't drop the section.
- Don't change any ClickUp status or Kiwi result. This skill only reads.
- Build the whole report before asking anything. List what you couldn't get under
  "Gaps in this report", then offer to fill specific gaps if she can supply the missing details.
