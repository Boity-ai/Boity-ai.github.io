#!/usr/bin/env node
// Kiwi TCMS JSON-RPC helper for the QA skills. Node 18+ (built-in fetch), no installs.
// Talks to Kiwi's API at <KIWI_URL>/json-rpc/. Never touches the database directly.
// Env: KIWI_URL (e.g. https://kiwi.example.co.za), KIWI_USERNAME, KIWI_PASSWORD (dedicated API user).
//
// Usage:
//   node kiwi.mjs ping                                   check login works
//   node kiwi.mjs find-case "<text>"                     cases whose summary contains text
//   node kiwi.mjs create-case '<json values>'            TestCase.create (needs summary, product, category, priority, case_status)
//   node kiwi.mjs add-to-plan <planId> <caseId>          add a case to a test plan
//   node kiwi.mjs add-to-run <runId> <caseId>            add a case to a run; returns the execution(s)
//   node kiwi.mjs executions '<json query>'              TestExecution.filter, e.g. '{"run": 12, "case": 34}'
//   node kiwi.mjs fail <executionId> "<comment>"         set execution to FAILED and add the comment
//   node kiwi.mjs pass <executionId> "<comment>"         set execution to PASSED and add the comment
//   node kiwi.mjs new-run <planId> <buildId> <caseId> "<summary>"   new run with just this case; returns the execution
//   node kiwi.mjs build <versionId> "<name>"            find a build (environment) by name, or create it
//   node kiwi.mjs link <executionId> <url> "<name>"      add a link (ClickUp task, failure doc) to an execution
//   node kiwi.mjs run-summary <runId>                    status counts and failed cases for a run
//   node kiwi.mjs tested-tickets <start> <end> [planId]   results per ClickUp ticket (TID-), with comments
//   node kiwi.mjs by-environment <start> <end> [planId]   results totalled per build (environment), end date excluded
//   node kiwi.mjs activity-since <YYYY-MM-DD>            executions finished since a date, grouped by run
//   node kiwi.mjs call <Method.name> '<json params array>'   any other API method (read-only use preferred)

const { KIWI_URL, KIWI_USERNAME, KIWI_PASSWORD } = process.env;
if (!KIWI_URL || !KIWI_USERNAME || !KIWI_PASSWORD) {
  console.error('Set KIWI_URL, KIWI_USERNAME and KIWI_PASSWORD. See the qa-workflow README, "Kiwi API user".');
  process.exit(2);
}
const ENDPOINT = KIWI_URL.replace(/\/+$/, '') + '/json-rpc/';
let cookie = '';
let rpcId = 0;

async function rpc(method, params = []) {
  let res;
  try {
    res = await fetch(ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) },
      body: JSON.stringify({ jsonrpc: '2.0', method, params, id: ++rpcId }),
    });
  } catch (e) {
    console.error(`Can't reach Kiwi at ${ENDPOINT}: ${e.cause?.code || e.message}. ` +
      'Check that you are on the network or VPN that can open Kiwi.');
    process.exit(1);
  }
  const setCookie = res.headers.getSetCookie?.() || [];
  const sid = setCookie.map(c => c.split(';')[0]).find(c => c.startsWith('sessionid='));
  if (sid) cookie = sid;
  const data = await res.json().catch(() => null);
  if (!res.ok || !data) { console.error(`Kiwi HTTP ${res.status} on ${method}`); process.exit(1); }
  if (data.error) { console.error(`Kiwi error on ${method}: ${JSON.stringify(data.error)}`); process.exit(1); }
  return data.result;
}

const json = (s, what) => { try { return JSON.parse(s); } catch { console.error(`Invalid JSON for ${what}`); process.exit(2); } };
const out = (x) => console.log(JSON.stringify(x, null, 2));

await rpc('Auth.login', [KIWI_USERNAME, KIWI_PASSWORD]);
const [cmd, a, b, c] = process.argv.slice(2);

switch (cmd) {
  case 'ping':
    out({ ok: true, url: KIWI_URL, user: KIWI_USERNAME });
    break;
  case 'find-case':
    out((await rpc('TestCase.filter', [{ summary__icontains: a }]))
      .map(t => ({ id: t.id, summary: t.summary, case_status: t.case_status__name, category: t.category__name })));
    break;
  case 'create-case':
    out(await rpc('TestCase.create', [json(a, 'case values')]));
    break;
  case 'add-to-plan':
    out(await rpc('TestPlan.add_case', [Number(a), Number(b)]));
    break;
  case 'add-to-run':
    out(await rpc('TestRun.add_case', [Number(a), Number(b)]));
    break;
  case 'executions':
    out(await rpc('TestExecution.filter', [json(a, 'query')]));
    break;
  case 'fail':
  case 'pass': {
    const name = cmd === 'fail' ? 'FAILED' : 'PASSED';
    const [status] = await rpc('TestExecutionStatus.filter', [{ name }]);
    if (!status) { console.error(`No ${name} status found in this Kiwi instance.`); process.exit(1); }
    const updated = await rpc('TestExecution.update', [Number(a), { status: status.id }]);
    if (b) await rpc('TestExecution.add_comment', [Number(a), b]);
    out({ ok: true, execution: updated.id, status: updated.status__name || name, commented: Boolean(b) });
    break;
  }
  case 'new-run': {
    // One run per result: create a run in the plan on the build, add the case, return the execution.
    const [planId, buildId, caseId, summary] = [Number(a), Number(b), Number(c), process.argv[6]];
    if (!summary) { console.error('Usage: new-run <planId> <buildId> <caseId> "<summary>"'); process.exit(2); }
    const [me] = await rpc('User.filter', [{ username: KIWI_USERNAME }]);
    const run = await rpc('TestRun.create', [{ plan: planId, build: buildId, manager: me.id, summary }]);
    const executions = await rpc('TestRun.add_case', [run.id, caseId]);
    out({ run: run.id, summary: run.summary, execution: executions[0]?.id });
    break;
  }
  case 'build': {
    // Find a build by name (case-insensitive) under a product version, or create it.
    const versionId = Number(a);
    const existing = (await rpc('Build.filter', [{ version: versionId }]))
      .find(x => x.name.trim().toLowerCase() === String(b).trim().toLowerCase());
    if (existing) { out({ id: existing.id, name: existing.name, created: false }); break; }
    const created = await rpc('Build.create', [{ name: b, version: versionId, is_active: true }]);
    out({ id: created.id, name: created.name, created: true });
    break;
  }
  case 'link':
    out(await rpc('TestExecution.add_link', [{ execution: Number(a), url: b, name: c || b }]));
    break;
  case 'run-summary': {
    const ex = await rpc('TestExecution.filter', [{ run: Number(a) }]);
    const counts = {};
    for (const e of ex) counts[e.status__name] = (counts[e.status__name] || 0) + 1;
    out({ run: Number(a), total: ex.length, counts,
      failed: ex.filter(e => e.status__name === 'FAILED').map(e => ({ execution: e.id, case: e.case, summary: e.case__summary })) });
    break;
  }
  case 'tested-tickets': {
    // Every result finished in [start, end), grouped by ClickUp ticket (the TID- in the case title),
    // with the date, environment, status and comments (which hold the dev / pre-prod label).
    const query = { stop_date__gte: a, stop_date__lt: b };
    if (c) query.run__plan = Number(c);
    const ex = await rpc('TestExecution.filter', [query]);
    const tickets = {};
    for (const e of ex) {
      const tid = (String(e.case__summary).match(/TID-\d+/i) || ['no TID'])[0].toUpperCase();
      const comments = (await rpc('TestExecution.get_comments', [e.id])).map(x => x.comment);
      (tickets[tid] ||= { ticket: tid, case: e.case, summary: e.case__summary, results: [] }).results.push({
        execution: e.id, run: e.run, date: e.stop_date, environment: e.build__name, status: e.status__name, comments,
      });
    }
    for (const t of Object.values(tickets)) t.results.sort((x, y) => String(x.date).localeCompare(String(y.date)));
    out(Object.values(tickets));
    break;
  }
  case 'by-environment': {
    // Results totalled by build (environment) for executions finished in [start, end).
    const query = { stop_date__gte: a, stop_date__lt: b };
    if (c) query.run__plan = Number(c);
    const ex = await rpc('TestExecution.filter', [query]);
    const envs = {};
    for (const e of ex) {
      const name = e.build__name || 'unknown';
      const r = (envs[name] ||= { environment: name, total: 0, counts: {}, failed: [] });
      r.total++;
      r.counts[e.status__name] = (r.counts[e.status__name] || 0) + 1;
      if (e.status__name === 'FAILED') r.failed.push({ case: e.case, summary: e.case__summary, run: e.run });
    }
    out(Object.values(envs));
    break;
  }
  case 'activity-since': {
    const ex = await rpc('TestExecution.filter', [{ stop_date__gte: a }]);
    const runs = {};
    for (const e of ex) {
      const r = (runs[e.run] ||= { run: e.run, summary: null, counts: {}, failed: [] });
      r.counts[e.status__name] = (r.counts[e.status__name] || 0) + 1;
      if (e.status__name === 'FAILED') r.failed.push({ case: e.case, summary: e.case__summary });
    }
    const ids = Object.keys(runs).map(Number);
    if (ids.length) {
      for (const r of await rpc('TestRun.filter', [{ id__in: ids }])) {
        if (runs[r.id]) runs[r.id].summary = r.summary;
      }
    }
    out(Object.values(runs));
    break;
  }
  case 'call':
    out(await rpc(a, b ? json(b, 'params') : []));
    break;
  default:
    console.error('Commands: ping | find-case | create-case | add-to-plan | add-to-run | executions | fail | pass | new-run | build | link | run-summary | tested-tickets | by-environment | activity-since | call');
    process.exit(2);
}
await rpc('Auth.logout').catch(() => {});
