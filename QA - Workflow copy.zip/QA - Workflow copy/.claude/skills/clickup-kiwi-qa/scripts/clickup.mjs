#!/usr/bin/env node
// ClickUp REST API v2 helper for the QA skills. Node 18+ (built-in fetch), no installs.
// Auth: personal API token in the CLICKUP_API_TOKEN environment variable (starts with pk_).
// CLICKUP_TEAM_ID (workspace ID) is only needed for custom task IDs like ABC-123.
//
// Usage:
//   node clickup.mjs task <taskId>                    task details (status, list, assignees, description)
//   node clickup.mjs comments <taskId>                comments, newest first
//   node clickup.mjs comment <taskId> "<text>"        post a comment
//   node clickup.mjs status <taskId> "<status>"       change status (e.g. "in progress")
//   node clickup.mjs statuses <listId>                valid status names for a list
//   node clickup.mjs list-tasks <listId> [YYYY-MM-DD] tasks in a list, optionally updated since a date
//   node clickup.mjs in-testing ["<status>"]           every task in the workspace in "in testing" (needs CLICKUP_TEAM_ID)
//   node clickup.mjs time-in-status <taskId>          status history (needs the Time in Status ClickApp)

const BASE = 'https://api.clickup.com/api/v2';
const token = process.env.CLICKUP_API_TOKEN;
if (!token) {
  console.error('CLICKUP_API_TOKEN is not set. See the qa-workflow README, "ClickUp API token".');
  process.exit(2);
}

function taskPath(rawId, suffix = '') {
  let id = rawId.trim();
  const params = new URLSearchParams();
  if (/^CU-/i.test(id)) {
    id = id.slice(3);                       // "CU-86abc123" → default ID "86abc123"
  } else if (/^[A-Z]+-\d+$/i.test(id)) {    // custom task ID, e.g. "QA-123"
    if (!process.env.CLICKUP_TEAM_ID) {
      console.error(`"${id}" looks like a custom task ID; set CLICKUP_TEAM_ID to use it.`);
      process.exit(2);
    }
    params.set('custom_task_ids', 'true');
    params.set('team_id', process.env.CLICKUP_TEAM_ID);
  }
  const q = params.toString();
  return `/task/${encodeURIComponent(id)}${suffix}${q ? '?' + q : ''}`;
}

async function call(method, path, body) {
  const res = await fetch(BASE + path, {
    method,
    headers: { Authorization: token, 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  if (!res.ok) {
    console.error(`ClickUp API ${res.status} on ${method} ${path}: ${text}`);
    process.exit(1);
  }
  return text ? JSON.parse(text) : {};
}

const [cmd, a, b] = process.argv.slice(2);
const out = (x) => console.log(JSON.stringify(x, null, 2));

switch (cmd) {
  case 'task': {
    const t = await call('GET', taskPath(a));
    out({
      id: t.id, custom_id: t.custom_id, name: t.name, url: t.url,
      status: t.status?.status, list: t.list, assignees: t.assignees?.map(u => u.username || u.email),
      description: t.text_content, date_updated: t.date_updated,
    });
    break;
  }
  case 'comments': {
    const r = await call('GET', taskPath(a, '/comment'));
    out((r.comments || []).map(c => ({
      id: c.id, author: c.user?.username || c.user?.email,
      date: new Date(Number(c.date)).toISOString(), text: c.comment_text,
    })));
    break;
  }
  case 'comment': {
    if (!b) { console.error('Comment text required.'); process.exit(2); }
    const r = await call('POST', taskPath(a, '/comment'), { comment_text: b, notify_all: false });
    out({ ok: true, comment_id: r.id });
    break;
  }
  case 'status': {
    if (!b) { console.error('Status name required.'); process.exit(2); }
    const t = await call('PUT', taskPath(a), { status: b });
    out({ ok: true, id: t.id, status: t.status?.status });
    break;
  }
  case 'statuses': {
    const l = await call('GET', `/list/${encodeURIComponent(a)}`);
    out((l.statuses || []).map(s => s.status));
    break;
  }
  case 'list-tasks': {
    const tasks = [];
    for (let page = 0; ; page++) {
      const p = new URLSearchParams({ page: String(page), include_closed: 'true', subtasks: 'true' });
      if (b) p.set('date_updated_gt', String(new Date(b + 'T00:00:00+02:00').getTime()));
      const r = await call('GET', `/list/${encodeURIComponent(a)}/task?${p}`);
      tasks.push(...(r.tasks || []).map(t => ({
        id: t.id, custom_id: t.custom_id, name: t.name, url: t.url, status: t.status?.status,
        assignees: t.assignees?.map(u => u.username || u.email), date_updated: t.date_updated,
      })));
      if (r.last_page !== false || !(r.tasks || []).length) break;
    }
    out(tasks);
    break;
  }
  case 'in-testing': {
    // Every task in the workspace currently in the "in testing" status (needs CLICKUP_TEAM_ID).
    const team = process.env.CLICKUP_TEAM_ID;
    if (!team || !/^\d+$/.test(team)) { console.error('Set CLICKUP_TEAM_ID to the workspace ID.'); process.exit(2); }
    const tasks = [];
    for (let page = 0; ; page++) {
      const p = new URLSearchParams({ page: String(page), subtasks: 'true' });
      p.append('statuses[]', a || 'in testing');
      const r = await call('GET', `/team/${team}/task?${p}`);
      tasks.push(...(r.tasks || []).map(t => ({
        id: t.id, custom_id: t.custom_id, name: t.name, url: t.url, status: t.status?.status,
        list: t.list?.name, assignees: t.assignees?.map(u => u.username || u.email), date_updated: t.date_updated,
      })));
      if (r.last_page !== false || !(r.tasks || []).length) break;
    }
    out(tasks);
    break;
  }
  case 'time-in-status': {
    out(await call('GET', taskPath(a, '/time_in_status')));
    break;
  }
  default:
    console.error('Commands: task | comments | comment | status | statuses | list-tasks | in-testing | time-in-status');
    process.exit(2);
}
