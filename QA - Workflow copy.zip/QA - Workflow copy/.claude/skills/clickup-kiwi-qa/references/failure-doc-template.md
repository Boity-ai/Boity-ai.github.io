# Failure document template

```markdown
# Test failure — <ClickUp task title>

| Field | Value |
|---|---|
| ClickUp task | <ID + link> |
| Kiwi test case | <ID or "pending import"> |
| Dev or pre-prod | <dev / pre-prod> |
| Brand | <Asuer / BBB> |
| Environment | <environment, e.g. dev1, apex, sfdev, dev7> |
| Build / PR | <value or "Not provided"> |
| Tested by | Phumeza |
| Date | <YYYY-MM-DD> |
| Result | FAILED |

## Test summary
<1–3 sentences: what was tested and where it fails, based on the ClickUp comment.>

## Steps to reproduce
1. ...

## Expected result
<From the acceptance criteria or the comment.>

## Actual result
<Her words from the ClickUp comment, lightly cleaned up for grammar only.>

## Why it failed
<Her explanation. Add a cause only if she stated one.>

## Evidence
<Screenshots, record IDs, logs — or "Not provided".>
```
