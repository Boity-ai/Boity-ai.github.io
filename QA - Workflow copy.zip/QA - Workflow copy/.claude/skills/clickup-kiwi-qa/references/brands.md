# Brands and environments

Every ticket is for either **Asuer** or **BBB**. All three QA skills use this file to fill in
the brand. They all use the one `claude-qa` plan, so the brand doesn't change the plan.

## Environment → brand
Taken from the Odoo environments she has connected (2026-10-06). If an environment is missing
or wrong, update this table.

| Brand | Environments |
|---|---|
| Asuer | adder, agate, apex, aspen, dev1, dev8, prod |
| BBB | artest, badge, basalt, beacon, beech, birch, bloom, brook, dev6, dev7, sfdev |

## How to work out the brand
1. If she says the brand, use it.
2. Otherwise, look up the environment (the Kiwi build) in the table. Match the whole name,
   ignoring case: `dev6` is BBB and `dev8` is Asuer.
3. If the ClickUp task's space, folder or list names Asuer or BBB and that disagrees with the
   environment, ask. Don't pick one.
4. If the environment isn't in the table, ask. Never guess the brand. Once she answers, offer
   to add the environment to the table.

The brand is separate from the dev or pre-prod label. Never work out dev or pre-prod from the
brand or the environment.
