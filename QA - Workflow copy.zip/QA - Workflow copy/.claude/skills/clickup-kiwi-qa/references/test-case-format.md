# Kiwi test case — YAML import format

TODO: replace this with Phumeza's exact YAML-frontmatter format. The fields below are placeholders.

```yaml
---
summary: <ClickUp task title>
product: Asuer & BBB - Test Cases
category: <category>
priority: P2
case_status: CONFIRMED
is_automated: false
tags: [clickup-<task ID>, <Asuer | BBB>, <environment>]
plan: claude-qa
---
## Preconditions
...
## Steps
1. ...
## Expected result
...
```

Execution result to record after import: **FAILED** or **PASSED**, with the comment
"QA <failed | passed> on <dev | pre-prod>. Brand: <Asuer | BBB>. <actual result>".
