# Kiwi manual step list (when Kiwi can't be reached)

Fill in the angle-bracket values and hand this list over together with the YAML.
Use FAILED or PASSED to match the result.

1. Open Kiwi → Test Plans → **claude-qa** (or the plan she named).
2. If case **<ID>** exists, find it in the plan. Otherwise: Add test case → title
   "TID-<number>: <task title>", then paste the steps and expected result.
3. Tick the test case, then choose **New Test Run**.
4. Name the run "TID-<number>: <task title> — <environment> — <YYYY-MM-DD>" and pick the
   build **<environment>** (create it under the product if it doesn't exist).
5. In the new run, change the case's status to **<FAILED | PASSED>**.
6. In the execution comment, paste: "QA <failed | passed> on <dev | pre-prod>. Brand: <Asuer | BBB>.
   <actual result>" and the ClickUp link <link>.
7. Copy the Kiwi case ID back to Claude so the ClickUp comment can reference it.
