# Kiwi defaults

Look up IDs with, for example:
`node scripts/kiwi.mjs call TestPlan.filter '[{"pk": 3}]'`
`node scripts/kiwi.mjs call Category.filter '[{"product": 5}]'`
`node scripts/kiwi.mjs call Build.filter '[{"version__product": 5}]'`

## Test plan
Every new test case, Asuer or BBB, goes into one plan. Phumeza doesn't need to name it.
The brand is recorded in the execution comment, not by plan or product (see `brands.md`).
Use another plan only if she names one for that ticket.

| Plan | Plan ID | Product | Product ID | Version ID | Category ID |
|---|---|---|---|---|---|
| claude-qa | 3 | Asuer & BBB - Test Cases | 5 | 8 (unspecified) | 22 (--default--) |

## Case defaults
Default priority ID: 2 (P2)
Default case_status ID: 2 (CONFIRMED)

## Builds (environments)
Each build is an environment. Use the environment Phumeza wrote on the ClickUp ticket, exactly
as she wrote it: `node scripts/kiwi.mjs build 8 "<environment>"` finds that build under version 8,
or creates it if it doesn't exist yet. Don't use build 9 "unspecified".
