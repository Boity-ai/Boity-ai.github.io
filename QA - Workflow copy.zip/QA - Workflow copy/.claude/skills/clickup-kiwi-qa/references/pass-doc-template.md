# Pass document template

```markdown
# Test passed — <ClickUp task title>

| Field | Value |
|---|---|
| ClickUp task | <ID — link> |
| Kiwi test case | TC-<ID> (plan: <plan name>, ID <plan ID>) |
| Kiwi run / execution | Run <ID> / execution <ID> |
| Dev or pre-prod | <dev / pre-prod> |
| Brand | <Asuer / BBB> |
| Environment | <environment, e.g. dev1, apex, sfdev, dev7> |
| Build / PR | <value or "Not provided"> |
| Tested by | Phumeza |
| Date | <YYYY-MM-DD> |
| Result | PASSED |

## Test summary
<1–3 sentences: what was tested and what the fix or feature does, from the task and her comment.>

## Preconditions
<Logins, test accounts, records or settings needed — or "Not provided".>

## Steps
1. ...

## Expected result
<From the acceptance criteria or her comment.>

## Actual result
<Her words, or "PASSED" per test if she ran several.>

## Evidence
<Screenshots, record IDs, logs — or "Not provided".>

## History
<Earlier results for this ticket (e.g. a previous FAILED with its date and FAIL doc), or "None".>
```
