---
name: clickup-kiwi-qa
description: Turn a failed test on a ClickUp task (in the Testing status) into a Kiwi TCMS test case and result, a failure document for Akili, and a ClickUp status change back to In Progress. Use this whenever Phumeza says a ClickUp task or ticket failed testing, points Claude at a ClickUp task or comment explaining a failure ("TID-1234 failed, check my comment"), asks to log a failed test in Kiwi, or wants a failure document. Also use it when she pastes a ClickUp task ID or link alongside words like failed, broken, didn't pass, or bug, even if she doesn't name Kiwi or Akili.
---

# ClickUp → Kiwi → Akili failed-test workflow

Phumeza is the sole QA tester across Asuer and BBB environments. When a test fails, she
writes a comment on the ClickUp task explaining why. This skill turns that comment into:

1. A Kiwi TCMS test case with a FAILED result
2. A failure document she saves in Akili
3. A ClickUp comment linking it all, with the task moved back to **In Progress**

Her comment is the source of truth for what went wrong. Use her wording for the actual
result. Do not reinterpret it or add details she didn't give.

## ClickUp status flow

- A ticket that is ready for QA goes to **Testing**. That's where every task Phumeza is
  testing sits.
- When a test fails, the task moves from **Testing** back to **In Progress**.
- If the task is not in Testing when she reports a failure, say what status it's in and ask
  before changing it. It may already have been moved, or it may be the wrong task.

## Current connection level

- **ClickUp:** via the ClickUp REST API, using `scripts/clickup.mjs` (Node 18+, no installs).
  It authenticates with her personal token in the `CLICKUP_API_TOKEN` environment variable.
  Never print, log, or write the token into any file. If the script reports that the token
  isn't set, point her to the README section "ClickUp API token" and stop.

  Commands (run from the skill folder):
  - `node scripts/clickup.mjs task <id>`: status, list, assignees, description
  - `node scripts/clickup.mjs comments <id>`: comments, newest first
  - `node scripts/clickup.mjs comment <id> "<text>"`: post a comment
  - `node scripts/clickup.mjs status <id> "<status>"`: change the status
  - `node scripts/clickup.mjs statuses <listId>`: valid status names for a list

  IDs: tasks use custom IDs like `TID-5661` (the workspace ID is set in `CLICKUP_TEAM_ID`).
  The internal ID (`86abc123`, or `CU-86abc123`) also works.
- **Kiwi TCMS:** via Kiwi's JSON-RPC API, using `scripts/kiwi.mjs` with a dedicated API user
  (`KIWI_URL`, `KIWI_USERNAME`, `KIWI_PASSWORD` environment variables). Never print the password
  or write it into any file. Never connect to Kiwi's database directly.

  Commands (run from the skill folder):
  - `node scripts/kiwi.mjs find-case "<text>"`: look for an existing case first
  - `node scripts/kiwi.mjs create-case '<json>'`: needs summary, product, category, priority and
    case_status IDs. Take them from `references/kiwi-defaults.md`.
  - `node scripts/kiwi.mjs add-to-plan <planId> <caseId>`
  - `node scripts/kiwi.mjs new-run <planId> <buildId> <caseId> "<summary>"`: a new run with just
    this case, returns the execution ID. Every result gets its own new run.
  - `node scripts/kiwi.mjs executions '{"run": <runId>, "case": <caseId>}'`: find an existing execution
  - `node scripts/kiwi.mjs fail <executionId> "<actual result>"`: set FAILED and add the comment
  - `node scripts/kiwi.mjs build <versionId> "<environment>"`: find the build for the environment
    she wrote on the ClickUp ticket, or create it. Show it in the plan before "go", and say
    whether it's new.
  - `node scripts/kiwi.mjs link <executionId> <url> "<name>"`: link the ClickUp task and failure doc
  - `node scripts/kiwi.mjs call <Method> '<params>'`: for lookups such as `TestPlan.filter` or
    `TestRun.filter`. Don't use it for writes that aren't listed above.

  **Fallback:** if the script can't reach Kiwi (off the network or VPN, or a login error), say
  so plainly, then hand over BOTH the YAML file (`references/test-case-format.md`) and the
  click-through steps (`references/kiwi-manual-steps.md`), so she can enter it herself.
- **Akili:** documents go in the **Test** folder. See "Akili" below for when Claude saves them
  there and when she uploads them herself.

## Akili (every test, pass or fail)
Every test result gets a document, saved in two places:
1. **This folder:** `tests/` at the project root (`FAIL-<task ID>-<slug>.md` or
   `PASS-<task ID>-<slug>.md`). Always do this first.
2. **Akili, under Test:** if Akili tools are available in this session, save the same document
   into the **Test** folder in Akili and confirm where it landed. If they aren't (the claude.ai
   Akili connector needs to be authorised in claude.ai connector settings), say so and tell her
   to upload the file from `tests/` to **Test** in Akili herself. Never claim it's in Akili
   unless the save succeeded.

### Kiwi setup notes
- Kiwi runs on a server backed by a database. Phumeza manages it.
- All access goes through the API user, so Kiwi's history shows these changes were made via
  the API, separately from her own work.

## Workflow

### 1. Gather
- Get the ClickUp task (`task`, then `comments`): title, description, acceptance criteria, status, list, and the
  most recent comment describing the failure. If several comments could be the failure
  note, ask which one.
- Work out the environment (for example dev1 or apex for Asuer, sfdev or dev7 for BBB). If
  the task or comment doesn't say, ask. Never guess the environment.
- Work out the **brand**, Asuer or BBB, using `references/brands.md`. If the environment isn't
  listed there, or the ClickUp space or list says a different brand, ask. The brand goes in the
  Kiwi comment, the ClickUp comment and the failure document.
- Get the **dev or pre-prod** label. She says which one when she reports the failure. If she
  doesn't, ask. Use her label exactly, and never work it out from the environment name. The
  two-weekly report counts failures from this label, so it goes in the Kiwi comment, the
  ClickUp comment and the failure document.
- Note anything missing that the failure document needs: steps to reproduce, expected
  result, evidence (screenshots, record IDs), build or PR. Ask for these once, together.
  If she says she doesn't have them, mark them "Not provided".
- Kiwi **Test Plan**: use the `claude-qa` plan (ID 3) from `references/kiwi-defaults.md` for
  every ticket, Asuer or BBB. Use a different plan only if she names one for that ticket.

### 2. Show the plan and wait
Show a short numbered plan:
1. The brand, the Kiwi case (new or existing), the build, and the new run it goes into, marked FAILED
2. The failure document you'll write, saved to `tests/` and to Test in Akili
3. The ClickUp comment you'll post, and the status change from Testing to In Progress

Then ask her to reply "go". **Do not write to Kiwi, post to ClickUp or change a status before she says go.**

### 3. Kiwi (after "go")
1. `find-case` using the ClickUp task title. If a matching case exists, use it. Otherwise
   `create-case` (IDs from `references/kiwi-defaults.md`), then `add-to-plan` to the
   `claude-qa` plan, or to the plan she named.
2. `build 8 "<environment>"` to get the build for the environment on the ClickUp ticket.
   Then create a **new run for this result** (she never reuses runs):
   `new-run 3 <buildId> <caseId> "TID-<number>: <task title> — <environment> — <YYYY-MM-DD>"`.
   It returns the execution ID. Use a different plan ID only if she named one.
3. `fail <executionId> "QA failed on <dev|pre-prod>. Brand: <Asuer|BBB>. <actual result from her comment>"`.
4. After the failure doc is written, `link` the ClickUp task URL and the failure document's name.
5. Report the case ID, execution ID and run back to her.

### 4. Failure document
Write it using `references/failure-doc-template.md`. Save it as a Markdown file named
`FAIL-<ClickUp task ID>-<short-slug>.md` (e.g. `FAIL-TID-5661-dashboard-totals.md`) in the
`tests/` folder at the project root, then save it under **Test** in Akili (see "Akili" above).
If she asks for a branded PDF instead, use asuer-docs for an Asuer ticket and bbb-docs for a
BBB ticket.

### 5. ClickUp update (after "go")
- Post a comment on the task (`comment`):
  `QA failed on <dev|pre-prod> (<Asuer|BBB> <environment>) — <one-line summary>. Kiwi case: TC-<ID> (run <run name>).
  Failure document: <file name> (Akili › Test).`
- Move the task status from **Testing** to **In Progress** (`status`). Use the exact status
  name from `statuses <listId>` for the task's list, usually "in progress". Confirm that the
  returned status matches.
- Confirm what was done. Leave any step she still needs to do clearly marked as hers (for
  example, a Kiwi step after a fallback).

## Rules
- Never invent IDs, results, evidence, or steps. Leave them blank or mark them "Not provided".
- Kiwi is the source of truth for test results, and ClickUp for task status.
- If the ClickUp status change fails (e.g. the status name doesn't exist in that list),
  report it plainly and leave the status as it is.
- Keep the tone factual. The failure document is read by developers.
